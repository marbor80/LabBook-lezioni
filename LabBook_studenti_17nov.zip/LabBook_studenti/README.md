# LabBook – materiale per le squadre (17/11)

## tappa1-regole
Progetto da console delle regole di prenotazione (package `labbook`).
Solo per chi non ha più il progetto di ieri: New Project → Java Application,
creare il package `labbook` e copiarci i file `.java`. Run File su `ProvaRegole`.

## tappa2-prima-pagina
Prima pagina web. In NetBeans: File → Open Project → `tappa2-prima-pagina`,
Properties → Build → Compile → JDK 21, poi Run.
Indirizzo: http://localhost:8080/laboratori
