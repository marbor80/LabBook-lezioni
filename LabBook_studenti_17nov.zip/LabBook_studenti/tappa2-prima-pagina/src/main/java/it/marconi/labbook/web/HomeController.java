package it.marconi.labbook.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    // http://localhost:8080/ porta all'elenco dei laboratori
    @GetMapping("/")
    public String home() {
        return "redirect:/laboratori";
    }
}
