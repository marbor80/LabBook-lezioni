package it.marconi.labbook.model;

// La classe di giovedi': per ora i dati stanno in memoria
public class Laboratorio {

    private Long id;
    private String nome;
    private int postiPc;
    private String piano;

    public Laboratorio(Long id, String nome, int postiPc, String piano) {
        this.id = id;
        this.nome = nome;
        this.postiPc = postiPc;
        this.piano = piano;
    }

    public Long getId() { return id; }
    public String getNome() { return nome; }
    public int getPostiPc() { return postiPc; }
    public String getPiano() { return piano; }

    @Override
    public String toString() {
        return nome + " (" + postiPc + " PC, piano " + piano + ")";
    }
}
