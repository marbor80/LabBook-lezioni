package it.marconi.labbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Il punto di partenza: avvia il server web su http://localhost:8080
@SpringBootApplication
public class LabBookApplication {

    public static void main(String[] args) {
        SpringApplication.run(LabBookApplication.class, args);
    }
}
