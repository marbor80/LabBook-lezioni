package it.marconi.labbook.web;

import it.marconi.labbook.model.Laboratorio;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

// Controller: riceve la richiesta del browser e sceglie la pagina da mostrare
@Controller
public class LaboratorioController {

    // GET http://localhost:8080/laboratori
    @GetMapping("/laboratori")
    public String elenco(Model model) {
        List<Laboratorio> laboratori = new ArrayList<>();
        laboratori.add(new Laboratorio(1L, "Informatica 1", 24, "terra"));
        laboratori.add(new Laboratorio(2L, "Informatica 2", 20, "terra"));
        laboratori.add(new Laboratorio(3L, "Sistemi e Reti", 16, "primo"));
        laboratori.add(new Laboratorio(4L, "Multimediale", 20, "primo"));

        model.addAttribute("laboratori", laboratori);   // i dati per la pagina
        return "laboratori";                            // -> templates/laboratori.html
    }
}
