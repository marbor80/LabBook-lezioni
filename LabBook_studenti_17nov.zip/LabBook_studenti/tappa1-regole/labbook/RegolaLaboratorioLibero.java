package labbook;

import java.util.List;

// RF3: niente doppie prenotazioni (flusso alternativo 3a di "Prenota laboratorio")
public class RegolaLaboratorioLibero implements Regola {

    @Override
    public String verifica(Prenotazione nuova, List<Prenotazione> esistenti) {
        for (Prenotazione p : esistenti) {
            if (p.stessoSlot(nuova)) {
                return "Laboratorio già occupato da " + p.getClasse();
            }
        }
        return null;
    }
}
