package labbook;

import java.time.LocalDate;

public class ProvaRegole {

    public static void main(String[] args) {
        // data fissa: così i test danno sempre lo stesso risultato
        LocalDate oggi = LocalDate.of(2026, 11, 13);
        LocalDate lun = LocalDate.of(2026, 11, 16);

        Laboratorio info1 = new Laboratorio(1, "Lab Informatica 1", 24, "terra");
        Laboratorio reti = new Laboratorio(2, "Lab Sistemi e Reti", 16, "primo");

        GestorePrenotazioni gestore = new GestorePrenotazioni();
        // LIVELLO 2: togli il commento dalla riga qui sotto
        // gestore.aggiungiRegola(new RegolaDataConsentita(oggi));
        gestore.aggiungiRegola(new RegolaLaboratorioLibero());

        System.out.println("--- Casi di prova (oggi = " + oggi + ") ---");
        stampa("1 Lab 1, 16/11, 2a ora", gestore.prenota(new Prenotazione(1, info1, lun, 2, "Rossi", "4A", "")));
        stampa("2 Lab 1, 16/11, 3a ora", gestore.prenota(new Prenotazione(2, info1, lun, 3, "Bianchi", "5B", "")));
        stampa("3 Lab 1, 16/11, 2a ora", gestore.prenota(new Prenotazione(3, info1, lun, 2, "Verdi", "3C", "")));
        stampa("4 Reti, ieri", gestore.prenota(new Prenotazione(4, reti, oggi.minusDays(1), 1, "Esposito", "4B", "")));
        stampa("5 Reti, tra 30 giorni", gestore.prenota(new Prenotazione(5, reti, oggi.plusDays(30), 1, "Esposito", "4B", "")));
        stampa("6 Reti, tra 14 giorni", gestore.prenota(new Prenotazione(6, reti, oggi.plusDays(14), 1, "Esposito", "4B", "")));
        stampa("7 Reti, oggi", gestore.prenota(new Prenotazione(7, reti, oggi, 5, "Neri", "5A", "")));

        // SFIDA
        System.out.println("--- Quadro del " + lun + " ---");
        for (Prenotazione p : gestore.elencoDelGiorno(lun)) {
            System.out.println(p);
        }
    }

    static void stampa(String caso, String errore) {
        if (errore == null) {
            System.out.println(caso + ": OK");
        } else {
            System.out.println(caso + ": RIFIUTATA - " + errore);
        }
    }
}
