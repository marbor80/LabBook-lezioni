package labbook;

public class Laboratorio {

    private int id;
    private String nome;
    private int postiPc;
    private String piano;

    public Laboratorio(int id, String nome, int postiPc, String piano) {
        this.id = id;
        this.nome = nome;
        this.postiPc = postiPc;
        this.piano = piano;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public int getPostiPc() { return postiPc; }
    public String getPiano() { return piano; }

    @Override
    public String toString() {
        return nome + " (" + postiPc + " PC, piano " + piano + ")";
    }
}
