package labbook;

import java.time.LocalDate;

public class LabBook {

    public static void main(String[] args) {
        // Livello 1: due laboratori e tre prenotazioni
        Laboratorio info1 = new Laboratorio(1, "Lab Informatica 1", 24, "terra");
        Laboratorio reti = new Laboratorio(2, "Lab Sistemi e Reti", 16, "primo");
        LocalDate lun = LocalDate.of(2026, 11, 16);

        Prenotazione p1 = new Prenotazione(1, info1, lun, 2, "Rossi", "4A", "Verifica");
        Prenotazione p2 = new Prenotazione(2, info1, lun, 3, "Bianchi", "5B", "Progetto");
        Prenotazione p3 = new Prenotazione(3, reti, lun, 2, "Esposito", "4B", "");
        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);

        // Livello 2: ora non valida
        try {
            new Prenotazione(4, info1, lun, 9, "Verdi", "3C", "");
        } catch (IllegalArgumentException e) {
            System.out.println("Errore: " + e.getMessage());
        }

        // Livello 2: stessoSlot
        Prenotazione p5 = new Prenotazione(5, info1, lun, 2, "Verdi", "3C", "");
        System.out.println("p1 e p5 (stesso lab, data, ora): " + p1.stessoSlot(p5)); // true
        System.out.println("p1 e p2 (ora diversa): " + p1.stessoSlot(p2));          // false
        System.out.println("p1 e p3 (laboratorio diverso): " + p1.stessoSlot(p3)); // false
    }
}
