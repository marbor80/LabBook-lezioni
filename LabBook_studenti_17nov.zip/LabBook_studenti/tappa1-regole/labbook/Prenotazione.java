package labbook;

import java.time.LocalDate;

public class Prenotazione {

    private int id;
    private Laboratorio laboratorio;
    private LocalDate data;
    private int ora;          // ora di lezione: da 1 a 7
    private String docente;
    private String classe;
    private String motivo;    // facoltativo

    public Prenotazione(int id, Laboratorio laboratorio, LocalDate data, int ora,
                        String docente, String classe, String motivo) {
        if (ora < 1 || ora > 7) {
            throw new IllegalArgumentException("L'ora deve essere tra 1 e 7");
        }
        this.id = id;
        this.laboratorio = laboratorio;
        this.data = data;
        this.ora = ora;
        this.docente = docente;
        this.classe = classe;
        this.motivo = motivo;
    }

    public int getId() { return id; }
    public Laboratorio getLaboratorio() { return laboratorio; }
    public LocalDate getData() { return data; }
    public int getOra() { return ora; }
    public String getDocente() { return docente; }
    public String getClasse() { return classe; }
    public String getMotivo() { return motivo; }

    // true se le due prenotazioni occupano lo stesso laboratorio, lo stesso giorno, alla stessa ora
    public boolean stessoSlot(Prenotazione altra) {
        return this.laboratorio.getId() == altra.laboratorio.getId()
                && this.data.equals(altra.data)
                && this.ora == altra.ora;
    }

    @Override
    public String toString() {
        return data + " - " + ora + "a ora - " + laboratorio.getNome()
                + " - prof. " + docente + " (" + classe + ")";
    }
}
