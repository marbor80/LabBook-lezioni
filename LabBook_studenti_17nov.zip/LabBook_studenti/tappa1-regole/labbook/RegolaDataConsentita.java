package labbook;

import java.time.LocalDate;
import java.util.List;

// LIVELLO 2 - RF6: mai nel passato, al massimo 14 giorni da oggi
public class RegolaDataConsentita implements Regola {

    private LocalDate oggi;

    public RegolaDataConsentita(LocalDate oggi) {
        this.oggi = oggi;
    }

    @Override
    public String verifica(Prenotazione nuova, List<Prenotazione> esistenti) {
        // 1. se la data della prenotazione è prima di oggi
        //    restituisci "Non si può prenotare nel passato"
        // 2. se la data è dopo oggi + 14 giorni
        //    restituisci "Si può prenotare al massimo due settimane prima"
        // 3. altrimenti restituisci null

        return null;
    }
}
