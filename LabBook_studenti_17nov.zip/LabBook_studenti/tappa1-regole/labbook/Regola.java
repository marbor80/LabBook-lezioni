package labbook;

import java.util.List;

public interface Regola {
    // restituisce null se la prenotazione rispetta la regola, altrimenti il messaggio di errore
    String verifica(Prenotazione nuova, List<Prenotazione> esistenti);
}
