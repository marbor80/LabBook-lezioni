package labbook;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class GestorePrenotazioni {

    private List<Prenotazione> prenotazioni = new ArrayList<>();
    private List<Regola> regole = new ArrayList<>();

    public void aggiungiRegola(Regola r) {
        regole.add(r);
    }

    // restituisce null se la prenotazione è stata salvata, altrimenti il messaggio di errore
    public String prenota(Prenotazione nuova) {
        for (Regola r : regole) {                 // polimorfismo: ogni regola fa la sua verifica
            String errore = r.verifica(nuova, prenotazioni);
            if (errore != null) {
                return errore;                    // basta una regola che dice no
            }
        }
        prenotazioni.add(nuova);                  // tutte hanno detto sì: si salva
        return null;
    }

    // SFIDA: tutte le prenotazioni di un giorno
    public List<Prenotazione> elencoDelGiorno(LocalDate data) {
        List<Prenotazione> risultato = new ArrayList<>();
        for (Prenotazione p : prenotazioni) {
            if (p.getData().equals(data)) {
                risultato.add(p);
            }
        }
        return risultato;
    }
}
